# JogoDaVelha_POE
Repositório destinado ao armazenamento do projeto simples de jogo da velha para a disciplina de Programação Orientada a Eventos, desenvolvido com C#, .NET e Windows Forms pelo Visual Studio
