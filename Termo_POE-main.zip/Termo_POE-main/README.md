# Termo_POE
Repositório destinado ao desenvolvimento do jogo Termo como atividade para a disciplina de Programação Orientada a Eventos (POE) do meu curto de Engenharia de Computação. Termo é um jogo famoso de adivinhar uma palavra diária de 5 letras tendo até 6 tentativas.
