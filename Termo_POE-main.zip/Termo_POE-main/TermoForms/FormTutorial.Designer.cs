﻿namespace Termo
{
    partial class FormTutorial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTutorial));
            labelTitulo = new Label();
            labelAvisos = new Label();
            labelExemplo = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            label1 = new Label();
            label2 = new Label();
            button6 = new Button();
            button7 = new Button();
            label3 = new Label();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            label4 = new Label();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button15 = new Button();
            label5 = new Label();
            SuspendLayout();
            // 
            // labelTitulo
            // 
            labelTitulo.AutoSize = true;
            labelTitulo.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelTitulo.Location = new Point(166, 11);
            labelTitulo.Name = "labelTitulo";
            labelTitulo.Size = new Size(266, 37);
            labelTitulo.TabIndex = 0;
            labelTitulo.Text = "Bem-Vindo ao jogo";
            // 
            // labelAvisos
            // 
            labelAvisos.AutoSize = true;
            labelAvisos.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelAvisos.Location = new Point(5, 46);
            labelAvisos.Name = "labelAvisos";
            labelAvisos.Size = new Size(559, 140);
            labelAvisos.TabIndex = 1;
            labelAvisos.Text = resources.GetString("labelAvisos.Text");
            // 
            // labelExemplo
            // 
            labelExemplo.AutoSize = true;
            labelExemplo.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelExemplo.Location = new Point(242, 196);
            labelExemplo.Name = "labelExemplo";
            labelExemplo.Size = new Size(94, 25);
            labelExemplo.TabIndex = 2;
            labelExemplo.Text = "Exemplo:";
            // 
            // button1
            // 
            button1.BackColor = Color.Gray;
            button1.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button1.ForeColor = SystemColors.ButtonFace;
            button1.Location = new Point(99, 255);
            button1.Name = "button1";
            button1.Size = new Size(70, 70);
            button1.TabIndex = 3;
            button1.Text = "P";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.Gray;
            button2.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button2.ForeColor = SystemColors.ButtonFace;
            button2.Location = new Point(175, 255);
            button2.Name = "button2";
            button2.Size = new Size(70, 70);
            button2.TabIndex = 4;
            button2.Text = "O";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.Gray;
            button3.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button3.ForeColor = SystemColors.ButtonFace;
            button3.Location = new Point(251, 255);
            button3.Name = "button3";
            button3.Size = new Size(70, 70);
            button3.TabIndex = 5;
            button3.Text = "R";
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.Green;
            button4.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button4.ForeColor = SystemColors.ButtonFace;
            button4.Location = new Point(326, 255);
            button4.Name = "button4";
            button4.Size = new Size(70, 70);
            button4.TabIndex = 6;
            button4.Text = "T";
            button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = Color.Green;
            button5.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button5.ForeColor = SystemColors.ButtonFace;
            button5.Location = new Point(402, 255);
            button5.Name = "button5";
            button5.Size = new Size(70, 70);
            button5.TabIndex = 7;
            button5.Text = "O";
            button5.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(203, 225);
            label1.Name = "label1";
            label1.Size = new Size(164, 21);
            label1.TabIndex = 8;
            label1.Text = "Palavra secreta: TEXTO";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(99, 333);
            label2.Name = "label2";
            label2.Size = new Size(418, 42);
            label2.TabIndex = 9;
            label2.Text = "As letras                   pertencem a palavra secreta e estão no \r\nlugar certo.";
            // 
            // button6
            // 
            button6.BackColor = Color.Green;
            button6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.ForeColor = SystemColors.ButtonFace;
            button6.Location = new Point(167, 328);
            button6.Name = "button6";
            button6.Size = new Size(30, 30);
            button6.TabIndex = 10;
            button6.Text = "T";
            button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.Orange;
            button7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button7.ForeColor = SystemColors.ButtonFace;
            button7.Location = new Point(167, 460);
            button7.Name = "button7";
            button7.Size = new Size(30, 30);
            button7.TabIndex = 17;
            button7.Text = "O";
            button7.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(99, 465);
            label3.Name = "label3";
            label3.Size = new Size(400, 42);
            label3.TabIndex = 16;
            label3.Text = "As letras                    pertencem a palavra secreta, porém \r\nnão estão no lugar certo.";
            // 
            // button8
            // 
            button8.BackColor = Color.Orange;
            button8.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button8.ForeColor = SystemColors.ButtonFace;
            button8.Location = new Point(402, 382);
            button8.Name = "button8";
            button8.Size = new Size(70, 70);
            button8.TabIndex = 15;
            button8.Text = "E";
            button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            button9.BackColor = Color.Gray;
            button9.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button9.ForeColor = SystemColors.ButtonFace;
            button9.Location = new Point(326, 382);
            button9.Name = "button9";
            button9.Size = new Size(70, 70);
            button9.TabIndex = 14;
            button9.Text = "T";
            button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            button10.BackColor = Color.Gray;
            button10.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button10.ForeColor = SystemColors.ButtonFace;
            button10.Location = new Point(251, 382);
            button10.Name = "button10";
            button10.Size = new Size(70, 70);
            button10.TabIndex = 13;
            button10.Text = "N";
            button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            button11.BackColor = Color.Orange;
            button11.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button11.ForeColor = SystemColors.ButtonFace;
            button11.Location = new Point(175, 382);
            button11.Name = "button11";
            button11.Size = new Size(70, 70);
            button11.TabIndex = 12;
            button11.Text = "O";
            button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            button12.BackColor = Color.Gray;
            button12.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button12.ForeColor = SystemColors.ButtonFace;
            button12.Location = new Point(99, 382);
            button12.Name = "button12";
            button12.Size = new Size(70, 70);
            button12.TabIndex = 11;
            button12.Text = "M";
            button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            button13.BackColor = Color.Green;
            button13.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button13.ForeColor = SystemColors.ButtonFace;
            button13.Location = new Point(203, 328);
            button13.Name = "button13";
            button13.Size = new Size(30, 30);
            button13.TabIndex = 18;
            button13.Text = "O";
            button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            button14.BackColor = Color.Orange;
            button14.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button14.ForeColor = SystemColors.ButtonFace;
            button14.Location = new Point(203, 460);
            button14.Name = "button14";
            button14.Size = new Size(30, 30);
            button14.TabIndex = 19;
            button14.Text = "E";
            button14.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(99, 597);
            label4.Name = "label4";
            label4.Size = new Size(412, 21);
            label4.TabIndex = 25;
            label4.Text = "As letras estão pertencem a palavra e estão no lugar certo.";
            // 
            // button17
            // 
            button17.BackColor = Color.Green;
            button17.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button17.ForeColor = SystemColors.ButtonFace;
            button17.Location = new Point(402, 514);
            button17.Name = "button17";
            button17.Size = new Size(70, 70);
            button17.TabIndex = 24;
            button17.Text = "O";
            button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            button18.BackColor = Color.Green;
            button18.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button18.ForeColor = SystemColors.ButtonFace;
            button18.Location = new Point(326, 514);
            button18.Name = "button18";
            button18.Size = new Size(70, 70);
            button18.TabIndex = 23;
            button18.Text = "T";
            button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            button19.BackColor = Color.Green;
            button19.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button19.ForeColor = SystemColors.ButtonFace;
            button19.Location = new Point(251, 514);
            button19.Name = "button19";
            button19.Size = new Size(70, 70);
            button19.TabIndex = 22;
            button19.Text = "X";
            button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            button20.BackColor = Color.Green;
            button20.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button20.ForeColor = SystemColors.ButtonFace;
            button20.Location = new Point(175, 514);
            button20.Name = "button20";
            button20.Size = new Size(70, 70);
            button20.TabIndex = 21;
            button20.Text = "E";
            button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            button21.BackColor = Color.Green;
            button21.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button21.ForeColor = SystemColors.ButtonFace;
            button21.Location = new Point(99, 514);
            button21.Name = "button21";
            button21.Size = new Size(70, 70);
            button21.TabIndex = 20;
            button21.Text = "T";
            button21.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            button15.Font = new Font("Segoe UI", 12F);
            button15.Location = new Point(411, 650);
            button15.Name = "button15";
            button15.Size = new Size(137, 39);
            button15.TabIndex = 26;
            button15.Text = "Entendido";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button15_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F);
            label5.Location = new Point(1, 659);
            label5.Name = "label5";
            label5.Size = new Size(304, 21);
            label5.TabIndex = 27;
            label5.Text = "Clique em Entendido para começar a jogar";
            // 
            // FormTutorial
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(575, 701);
            Controls.Add(label5);
            Controls.Add(button15);
            Controls.Add(label4);
            Controls.Add(button17);
            Controls.Add(button18);
            Controls.Add(button19);
            Controls.Add(button20);
            Controls.Add(button21);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button7);
            Controls.Add(label3);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button6);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(labelExemplo);
            Controls.Add(labelAvisos);
            Controls.Add(labelTitulo);
            MaximizeBox = false;
            Name = "FormTutorial";
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelTitulo;
        private Label labelAvisos;
        private Label labelExemplo;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Label label1;
        private Label label2;
        private Button button6;
        private Button button7;
        private Label label3;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Label label4;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button15;
        private Label label5;
    }
}