﻿namespace Termo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            button25 = new Button();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            button29 = new Button();
            button30 = new Button();
            button31 = new Button();
            button32 = new Button();
            button33 = new Button();
            button34 = new Button();
            button35 = new Button();
            button36 = new Button();
            button37 = new Button();
            button38 = new Button();
            button39 = new Button();
            button40 = new Button();
            button41 = new Button();
            button42 = new Button();
            button43 = new Button();
            button44 = new Button();
            button45 = new Button();
            button46 = new Button();
            button47 = new Button();
            button48 = new Button();
            button49 = new Button();
            button50 = new Button();
            button51 = new Button();
            button52 = new Button();
            button54 = new Button();
            button56 = new Button();
            button58 = new Button();
            button59 = new Button();
            button60 = new Button();
            button53 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 25.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.DeepSkyBlue;
            label1.Location = new Point(252, 14);
            label1.Name = "label1";
            label1.Size = new Size(142, 39);
            label1.TabIndex = 0;
            label1.Text = "TERMO";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(33, 33, 33);
            button1.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button1.FlatAppearance.BorderSize = 3;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(435, 66);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(60, 60);
            button1.TabIndex = 3;
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(33, 33, 33);
            button2.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button2.FlatAppearance.BorderSize = 3;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(368, 66);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(60, 60);
            button2.TabIndex = 4;
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(33, 33, 33);
            button3.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button3.FlatAppearance.BorderSize = 3;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button3.ForeColor = Color.White;
            button3.Location = new Point(302, 66);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(60, 60);
            button3.TabIndex = 6;
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(33, 33, 33);
            button4.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button4.FlatAppearance.BorderSize = 3;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button4.ForeColor = Color.White;
            button4.Location = new Point(236, 66);
            button4.Margin = new Padding(3, 2, 3, 2);
            button4.Name = "button4";
            button4.Size = new Size(60, 60);
            button4.TabIndex = 5;
            button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(33, 33, 33);
            button5.FlatAppearance.BorderColor = Color.DeepSkyBlue;
            button5.FlatAppearance.BorderSize = 3;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button5.ForeColor = Color.White;
            button5.Location = new Point(169, 66);
            button5.Margin = new Padding(3, 2, 3, 2);
            button5.Name = "button5";
            button5.Size = new Size(60, 60);
            button5.TabIndex = 7;
            button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(33, 33, 33);
            button6.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button6.FlatAppearance.BorderSize = 3;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button6.ForeColor = Color.White;
            button6.Location = new Point(435, 130);
            button6.Margin = new Padding(3, 2, 3, 2);
            button6.Name = "button6";
            button6.Size = new Size(60, 60);
            button6.TabIndex = 12;
            button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(33, 33, 33);
            button7.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button7.FlatAppearance.BorderSize = 3;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button7.ForeColor = Color.White;
            button7.Location = new Point(369, 130);
            button7.Margin = new Padding(3, 2, 3, 2);
            button7.Name = "button7";
            button7.Size = new Size(60, 60);
            button7.TabIndex = 11;
            button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            button8.BackColor = Color.FromArgb(33, 33, 33);
            button8.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button8.FlatAppearance.BorderSize = 3;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button8.ForeColor = Color.White;
            button8.Location = new Point(302, 130);
            button8.Margin = new Padding(3, 2, 3, 2);
            button8.Name = "button8";
            button8.Size = new Size(60, 60);
            button8.TabIndex = 10;
            button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            button9.BackColor = Color.FromArgb(33, 33, 33);
            button9.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button9.FlatAppearance.BorderSize = 3;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button9.ForeColor = Color.White;
            button9.Location = new Point(236, 130);
            button9.Margin = new Padding(3, 2, 3, 2);
            button9.Name = "button9";
            button9.Size = new Size(60, 60);
            button9.TabIndex = 9;
            button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            button10.BackColor = Color.FromArgb(33, 33, 33);
            button10.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button10.FlatAppearance.BorderSize = 3;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button10.ForeColor = Color.White;
            button10.Location = new Point(169, 130);
            button10.Margin = new Padding(3, 2, 3, 2);
            button10.Name = "button10";
            button10.Size = new Size(60, 60);
            button10.TabIndex = 8;
            button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            button11.BackColor = Color.FromArgb(33, 33, 33);
            button11.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button11.FlatAppearance.BorderSize = 3;
            button11.FlatStyle = FlatStyle.Flat;
            button11.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button11.ForeColor = Color.White;
            button11.Location = new Point(435, 194);
            button11.Margin = new Padding(3, 2, 3, 2);
            button11.Name = "button11";
            button11.Size = new Size(60, 60);
            button11.TabIndex = 17;
            button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            button12.BackColor = Color.FromArgb(33, 33, 33);
            button12.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button12.FlatAppearance.BorderSize = 3;
            button12.FlatStyle = FlatStyle.Flat;
            button12.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button12.ForeColor = Color.White;
            button12.Location = new Point(368, 194);
            button12.Margin = new Padding(3, 2, 3, 2);
            button12.Name = "button12";
            button12.Size = new Size(60, 60);
            button12.TabIndex = 16;
            button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            button13.BackColor = Color.FromArgb(33, 33, 33);
            button13.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button13.FlatAppearance.BorderSize = 3;
            button13.FlatStyle = FlatStyle.Flat;
            button13.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button13.ForeColor = Color.White;
            button13.Location = new Point(302, 194);
            button13.Margin = new Padding(3, 2, 3, 2);
            button13.Name = "button13";
            button13.Size = new Size(60, 60);
            button13.TabIndex = 15;
            button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            button14.BackColor = Color.FromArgb(33, 33, 33);
            button14.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button14.FlatAppearance.BorderSize = 3;
            button14.FlatStyle = FlatStyle.Flat;
            button14.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button14.ForeColor = Color.White;
            button14.Location = new Point(234, 194);
            button14.Margin = new Padding(3, 2, 3, 2);
            button14.Name = "button14";
            button14.Size = new Size(60, 60);
            button14.TabIndex = 14;
            button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            button15.BackColor = Color.FromArgb(33, 33, 33);
            button15.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button15.FlatAppearance.BorderSize = 3;
            button15.FlatStyle = FlatStyle.Flat;
            button15.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button15.ForeColor = Color.White;
            button15.Location = new Point(169, 194);
            button15.Margin = new Padding(3, 2, 3, 2);
            button15.Name = "button15";
            button15.Size = new Size(60, 60);
            button15.TabIndex = 13;
            button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            button16.BackColor = Color.FromArgb(33, 33, 33);
            button16.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button16.FlatAppearance.BorderSize = 3;
            button16.FlatStyle = FlatStyle.Flat;
            button16.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button16.ForeColor = Color.White;
            button16.Location = new Point(435, 258);
            button16.Margin = new Padding(3, 2, 3, 2);
            button16.Name = "button16";
            button16.Size = new Size(60, 60);
            button16.TabIndex = 22;
            button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            button17.BackColor = Color.FromArgb(33, 33, 33);
            button17.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button17.FlatAppearance.BorderSize = 3;
            button17.FlatStyle = FlatStyle.Flat;
            button17.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button17.ForeColor = Color.White;
            button17.Location = new Point(368, 258);
            button17.Margin = new Padding(3, 2, 3, 2);
            button17.Name = "button17";
            button17.Size = new Size(60, 60);
            button17.TabIndex = 21;
            button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            button18.BackColor = Color.FromArgb(33, 33, 33);
            button18.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button18.FlatAppearance.BorderSize = 3;
            button18.FlatStyle = FlatStyle.Flat;
            button18.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button18.ForeColor = Color.White;
            button18.Location = new Point(302, 258);
            button18.Margin = new Padding(3, 2, 3, 2);
            button18.Name = "button18";
            button18.Size = new Size(60, 60);
            button18.TabIndex = 20;
            button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            button19.BackColor = Color.FromArgb(33, 33, 33);
            button19.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button19.FlatAppearance.BorderSize = 3;
            button19.FlatStyle = FlatStyle.Flat;
            button19.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button19.ForeColor = Color.White;
            button19.Location = new Point(234, 258);
            button19.Margin = new Padding(3, 2, 3, 2);
            button19.Name = "button19";
            button19.Size = new Size(60, 60);
            button19.TabIndex = 19;
            button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            button20.BackColor = Color.FromArgb(33, 33, 33);
            button20.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button20.FlatAppearance.BorderSize = 3;
            button20.FlatStyle = FlatStyle.Flat;
            button20.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button20.ForeColor = Color.White;
            button20.Location = new Point(169, 258);
            button20.Margin = new Padding(3, 2, 3, 2);
            button20.Name = "button20";
            button20.Size = new Size(60, 60);
            button20.TabIndex = 18;
            button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            button21.BackColor = Color.FromArgb(33, 33, 33);
            button21.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button21.FlatAppearance.BorderSize = 3;
            button21.FlatStyle = FlatStyle.Flat;
            button21.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button21.ForeColor = Color.White;
            button21.Location = new Point(435, 322);
            button21.Margin = new Padding(3, 2, 3, 2);
            button21.Name = "button21";
            button21.Size = new Size(60, 60);
            button21.TabIndex = 27;
            button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            button22.BackColor = Color.FromArgb(33, 33, 33);
            button22.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button22.FlatAppearance.BorderSize = 3;
            button22.FlatStyle = FlatStyle.Flat;
            button22.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button22.ForeColor = Color.White;
            button22.Location = new Point(368, 322);
            button22.Margin = new Padding(3, 2, 3, 2);
            button22.Name = "button22";
            button22.Size = new Size(60, 60);
            button22.TabIndex = 26;
            button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            button23.BackColor = Color.FromArgb(33, 33, 33);
            button23.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button23.FlatAppearance.BorderSize = 3;
            button23.FlatStyle = FlatStyle.Flat;
            button23.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button23.ForeColor = Color.White;
            button23.Location = new Point(302, 322);
            button23.Margin = new Padding(3, 2, 3, 2);
            button23.Name = "button23";
            button23.Size = new Size(60, 60);
            button23.TabIndex = 25;
            button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            button24.BackColor = Color.FromArgb(33, 33, 33);
            button24.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button24.FlatAppearance.BorderSize = 3;
            button24.FlatStyle = FlatStyle.Flat;
            button24.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button24.ForeColor = Color.White;
            button24.Location = new Point(234, 322);
            button24.Margin = new Padding(3, 2, 3, 2);
            button24.Name = "button24";
            button24.Size = new Size(60, 60);
            button24.TabIndex = 24;
            button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            button25.BackColor = Color.FromArgb(33, 33, 33);
            button25.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button25.FlatAppearance.BorderSize = 3;
            button25.FlatStyle = FlatStyle.Flat;
            button25.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button25.ForeColor = Color.White;
            button25.Location = new Point(169, 322);
            button25.Margin = new Padding(3, 2, 3, 2);
            button25.Name = "button25";
            button25.Size = new Size(60, 60);
            button25.TabIndex = 23;
            button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            button26.BackColor = Color.FromArgb(33, 33, 33);
            button26.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button26.FlatAppearance.BorderSize = 3;
            button26.FlatStyle = FlatStyle.Flat;
            button26.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button26.ForeColor = Color.White;
            button26.Location = new Point(435, 386);
            button26.Margin = new Padding(3, 2, 3, 2);
            button26.Name = "button26";
            button26.Size = new Size(60, 60);
            button26.TabIndex = 32;
            button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            button27.BackColor = Color.FromArgb(33, 33, 33);
            button27.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button27.FlatAppearance.BorderSize = 3;
            button27.FlatStyle = FlatStyle.Flat;
            button27.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button27.ForeColor = Color.White;
            button27.Location = new Point(368, 386);
            button27.Margin = new Padding(3, 2, 3, 2);
            button27.Name = "button27";
            button27.Size = new Size(60, 60);
            button27.TabIndex = 31;
            button27.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            button28.BackColor = Color.FromArgb(33, 33, 33);
            button28.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button28.FlatAppearance.BorderSize = 3;
            button28.FlatStyle = FlatStyle.Flat;
            button28.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button28.ForeColor = Color.White;
            button28.Location = new Point(302, 386);
            button28.Margin = new Padding(3, 2, 3, 2);
            button28.Name = "button28";
            button28.Size = new Size(60, 60);
            button28.TabIndex = 30;
            button28.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            button29.BackColor = Color.FromArgb(33, 33, 33);
            button29.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button29.FlatAppearance.BorderSize = 3;
            button29.FlatStyle = FlatStyle.Flat;
            button29.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button29.ForeColor = Color.White;
            button29.Location = new Point(234, 386);
            button29.Margin = new Padding(3, 2, 3, 2);
            button29.Name = "button29";
            button29.Size = new Size(60, 60);
            button29.TabIndex = 29;
            button29.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            button30.BackColor = Color.FromArgb(33, 33, 33);
            button30.FlatAppearance.BorderColor = SystemColors.ButtonFace;
            button30.FlatAppearance.BorderSize = 3;
            button30.FlatStyle = FlatStyle.Flat;
            button30.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Bold);
            button30.ForeColor = Color.White;
            button30.Location = new Point(169, 386);
            button30.Margin = new Padding(3, 2, 3, 2);
            button30.Name = "button30";
            button30.Size = new Size(60, 60);
            button30.TabIndex = 28;
            button30.UseVisualStyleBackColor = false;
            // 
            // button31
            // 
            button31.BackColor = Color.FromArgb(224, 224, 224);
            button31.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button31.FlatAppearance.BorderSize = 0;
            button31.FlatStyle = FlatStyle.Flat;
            button31.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button31.ForeColor = Color.FromArgb(51, 51, 51);
            button31.Location = new Point(107, 479);
            button31.Margin = new Padding(3, 2, 3, 2);
            button31.Name = "button31";
            button31.Size = new Size(40, 40);
            button31.TabIndex = 33;
            button31.Text = "Q";
            button31.UseVisualStyleBackColor = false;
            button31.Click += VirtualKeyboard_Letter_Click;
            // 
            // button32
            // 
            button32.BackColor = Color.FromArgb(224, 224, 224);
            button32.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button32.FlatAppearance.BorderSize = 0;
            button32.FlatStyle = FlatStyle.Flat;
            button32.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button32.ForeColor = Color.FromArgb(51, 51, 51);
            button32.Location = new Point(153, 479);
            button32.Margin = new Padding(3, 2, 3, 2);
            button32.Name = "button32";
            button32.Size = new Size(40, 40);
            button32.TabIndex = 34;
            button32.Text = "W";
            button32.UseVisualStyleBackColor = false;
            button32.Click += VirtualKeyboard_Letter_Click;
            // 
            // button33
            // 
            button33.BackColor = Color.FromArgb(224, 224, 224);
            button33.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button33.FlatAppearance.BorderSize = 0;
            button33.FlatStyle = FlatStyle.Flat;
            button33.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button33.ForeColor = Color.FromArgb(51, 51, 51);
            button33.Location = new Point(200, 479);
            button33.Margin = new Padding(3, 2, 3, 2);
            button33.Name = "button33";
            button33.Size = new Size(40, 40);
            button33.TabIndex = 35;
            button33.Text = "E";
            button33.UseVisualStyleBackColor = false;
            button33.Click += VirtualKeyboard_Letter_Click;
            // 
            // button34
            // 
            button34.BackColor = Color.FromArgb(224, 224, 224);
            button34.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button34.FlatAppearance.BorderSize = 0;
            button34.FlatStyle = FlatStyle.Flat;
            button34.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button34.ForeColor = Color.FromArgb(51, 51, 51);
            button34.Location = new Point(245, 479);
            button34.Margin = new Padding(3, 2, 3, 2);
            button34.Name = "button34";
            button34.Size = new Size(40, 40);
            button34.TabIndex = 36;
            button34.Text = "R";
            button34.UseVisualStyleBackColor = false;
            button34.Click += VirtualKeyboard_Letter_Click;
            // 
            // button35
            // 
            button35.BackColor = Color.FromArgb(224, 224, 224);
            button35.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button35.FlatAppearance.BorderSize = 0;
            button35.FlatStyle = FlatStyle.Flat;
            button35.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button35.ForeColor = Color.FromArgb(51, 51, 51);
            button35.Location = new Point(291, 479);
            button35.Margin = new Padding(3, 2, 3, 2);
            button35.Name = "button35";
            button35.Size = new Size(40, 40);
            button35.TabIndex = 37;
            button35.Text = "T";
            button35.UseVisualStyleBackColor = false;
            button35.Click += VirtualKeyboard_Letter_Click;
            // 
            // button36
            // 
            button36.BackColor = Color.FromArgb(224, 224, 224);
            button36.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button36.FlatAppearance.BorderSize = 0;
            button36.FlatStyle = FlatStyle.Flat;
            button36.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button36.ForeColor = Color.FromArgb(51, 51, 51);
            button36.Location = new Point(337, 479);
            button36.Margin = new Padding(3, 2, 3, 2);
            button36.Name = "button36";
            button36.Size = new Size(40, 40);
            button36.TabIndex = 38;
            button36.Text = "Y";
            button36.UseVisualStyleBackColor = false;
            button36.Click += VirtualKeyboard_Letter_Click;
            // 
            // button37
            // 
            button37.BackColor = Color.FromArgb(224, 224, 224);
            button37.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button37.FlatAppearance.BorderSize = 0;
            button37.FlatStyle = FlatStyle.Flat;
            button37.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button37.ForeColor = Color.FromArgb(51, 51, 51);
            button37.Location = new Point(383, 479);
            button37.Margin = new Padding(3, 2, 3, 2);
            button37.Name = "button37";
            button37.Size = new Size(40, 40);
            button37.TabIndex = 39;
            button37.Text = "U";
            button37.UseVisualStyleBackColor = false;
            button37.Click += VirtualKeyboard_Letter_Click;
            // 
            // button38
            // 
            button38.BackColor = Color.FromArgb(224, 224, 224);
            button38.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button38.FlatAppearance.BorderSize = 0;
            button38.FlatStyle = FlatStyle.Flat;
            button38.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button38.ForeColor = Color.FromArgb(51, 51, 51);
            button38.Location = new Point(429, 479);
            button38.Margin = new Padding(3, 2, 3, 2);
            button38.Name = "button38";
            button38.Size = new Size(40, 40);
            button38.TabIndex = 40;
            button38.Text = "I";
            button38.UseVisualStyleBackColor = false;
            button38.Click += VirtualKeyboard_Letter_Click;
            // 
            // button39
            // 
            button39.BackColor = Color.FromArgb(224, 224, 224);
            button39.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button39.FlatAppearance.BorderSize = 0;
            button39.FlatStyle = FlatStyle.Flat;
            button39.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button39.ForeColor = Color.FromArgb(51, 51, 51);
            button39.Location = new Point(475, 479);
            button39.Margin = new Padding(3, 2, 3, 2);
            button39.Name = "button39";
            button39.Size = new Size(40, 40);
            button39.TabIndex = 41;
            button39.Text = "O";
            button39.UseVisualStyleBackColor = false;
            button39.Click += VirtualKeyboard_Letter_Click;
            // 
            // button40
            // 
            button40.BackColor = Color.FromArgb(224, 224, 224);
            button40.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button40.FlatAppearance.BorderSize = 0;
            button40.FlatStyle = FlatStyle.Flat;
            button40.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button40.ForeColor = Color.FromArgb(51, 51, 51);
            button40.Location = new Point(522, 479);
            button40.Margin = new Padding(3, 2, 3, 2);
            button40.Name = "button40";
            button40.Size = new Size(40, 40);
            button40.TabIndex = 42;
            button40.Text = "P";
            button40.UseVisualStyleBackColor = false;
            button40.Click += VirtualKeyboard_Letter_Click;
            // 
            // button41
            // 
            button41.BackColor = Color.FromArgb(224, 224, 224);
            button41.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button41.FlatAppearance.BorderSize = 0;
            button41.FlatStyle = FlatStyle.Flat;
            button41.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button41.ForeColor = Color.FromArgb(51, 51, 51);
            button41.Location = new Point(133, 524);
            button41.Margin = new Padding(3, 2, 3, 2);
            button41.Name = "button41";
            button41.Size = new Size(40, 40);
            button41.TabIndex = 43;
            button41.Text = "A";
            button41.UseVisualStyleBackColor = false;
            button41.Click += VirtualKeyboard_Letter_Click;
            // 
            // button42
            // 
            button42.BackColor = Color.FromArgb(224, 224, 224);
            button42.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button42.FlatAppearance.BorderSize = 0;
            button42.FlatStyle = FlatStyle.Flat;
            button42.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button42.ForeColor = Color.FromArgb(51, 51, 51);
            button42.Location = new Point(179, 524);
            button42.Margin = new Padding(3, 2, 3, 2);
            button42.Name = "button42";
            button42.Size = new Size(40, 40);
            button42.TabIndex = 44;
            button42.Text = "S";
            button42.UseVisualStyleBackColor = false;
            button42.Click += VirtualKeyboard_Letter_Click;
            // 
            // button43
            // 
            button43.BackColor = Color.FromArgb(224, 224, 224);
            button43.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button43.FlatAppearance.BorderSize = 0;
            button43.FlatStyle = FlatStyle.Flat;
            button43.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button43.ForeColor = Color.FromArgb(51, 51, 51);
            button43.Location = new Point(225, 524);
            button43.Margin = new Padding(3, 2, 3, 2);
            button43.Name = "button43";
            button43.Size = new Size(40, 40);
            button43.TabIndex = 45;
            button43.Text = "D";
            button43.UseVisualStyleBackColor = false;
            button43.Click += VirtualKeyboard_Letter_Click;
            // 
            // button44
            // 
            button44.BackColor = Color.FromArgb(224, 224, 224);
            button44.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button44.FlatAppearance.BorderSize = 0;
            button44.FlatStyle = FlatStyle.Flat;
            button44.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button44.ForeColor = Color.FromArgb(51, 51, 51);
            button44.Location = new Point(271, 524);
            button44.Margin = new Padding(3, 2, 3, 2);
            button44.Name = "button44";
            button44.Size = new Size(40, 40);
            button44.TabIndex = 46;
            button44.Text = "F";
            button44.UseVisualStyleBackColor = false;
            button44.Click += VirtualKeyboard_Letter_Click;
            // 
            // button45
            // 
            button45.BackColor = Color.FromArgb(224, 224, 224);
            button45.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button45.FlatAppearance.BorderSize = 0;
            button45.FlatStyle = FlatStyle.Flat;
            button45.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button45.ForeColor = Color.FromArgb(51, 51, 51);
            button45.Location = new Point(317, 524);
            button45.Margin = new Padding(3, 2, 3, 2);
            button45.Name = "button45";
            button45.Size = new Size(40, 40);
            button45.TabIndex = 47;
            button45.Text = "G";
            button45.UseVisualStyleBackColor = false;
            button45.Click += VirtualKeyboard_Letter_Click;
            // 
            // button46
            // 
            button46.BackColor = Color.FromArgb(224, 224, 224);
            button46.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button46.FlatAppearance.BorderSize = 0;
            button46.FlatStyle = FlatStyle.Flat;
            button46.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button46.ForeColor = Color.FromArgb(51, 51, 51);
            button46.Location = new Point(363, 524);
            button46.Margin = new Padding(3, 2, 3, 2);
            button46.Name = "button46";
            button46.Size = new Size(40, 40);
            button46.TabIndex = 48;
            button46.Text = "H";
            button46.UseVisualStyleBackColor = false;
            button46.Click += VirtualKeyboard_Letter_Click;
            // 
            // button47
            // 
            button47.BackColor = Color.FromArgb(224, 224, 224);
            button47.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button47.FlatAppearance.BorderSize = 0;
            button47.FlatStyle = FlatStyle.Flat;
            button47.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button47.ForeColor = Color.FromArgb(51, 51, 51);
            button47.Location = new Point(410, 524);
            button47.Margin = new Padding(3, 2, 3, 2);
            button47.Name = "button47";
            button47.Size = new Size(40, 40);
            button47.TabIndex = 49;
            button47.Text = "J";
            button47.UseVisualStyleBackColor = false;
            button47.Click += VirtualKeyboard_Letter_Click;
            // 
            // button48
            // 
            button48.BackColor = Color.FromArgb(224, 224, 224);
            button48.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button48.FlatAppearance.BorderSize = 0;
            button48.FlatStyle = FlatStyle.Flat;
            button48.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button48.ForeColor = Color.FromArgb(51, 51, 51);
            button48.Location = new Point(455, 524);
            button48.Margin = new Padding(3, 2, 3, 2);
            button48.Name = "button48";
            button48.Size = new Size(40, 40);
            button48.TabIndex = 50;
            button48.Text = "K";
            button48.UseVisualStyleBackColor = false;
            button48.Click += VirtualKeyboard_Letter_Click;
            // 
            // button49
            // 
            button49.BackColor = Color.FromArgb(224, 224, 224);
            button49.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button49.FlatAppearance.BorderSize = 0;
            button49.FlatStyle = FlatStyle.Flat;
            button49.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button49.ForeColor = Color.FromArgb(51, 51, 51);
            button49.Location = new Point(501, 524);
            button49.Margin = new Padding(3, 2, 3, 2);
            button49.Name = "button49";
            button49.Size = new Size(40, 40);
            button49.TabIndex = 51;
            button49.Text = "L";
            button49.UseVisualStyleBackColor = false;
            button49.Click += VirtualKeyboard_Letter_Click;
            // 
            // button50
            // 
            button50.BackColor = Color.FromArgb(224, 224, 224);
            button50.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button50.FlatAppearance.BorderSize = 0;
            button50.FlatStyle = FlatStyle.Flat;
            button50.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button50.ForeColor = Color.FromArgb(51, 51, 51);
            button50.Location = new Point(179, 568);
            button50.Margin = new Padding(3, 2, 3, 2);
            button50.Name = "button50";
            button50.Size = new Size(40, 40);
            button50.TabIndex = 52;
            button50.Text = "Z";
            button50.UseVisualStyleBackColor = false;
            button50.Click += VirtualKeyboard_Letter_Click;
            // 
            // button51
            // 
            button51.BackColor = Color.FromArgb(224, 224, 224);
            button51.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button51.FlatAppearance.BorderSize = 0;
            button51.FlatStyle = FlatStyle.Flat;
            button51.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button51.ForeColor = Color.FromArgb(51, 51, 51);
            button51.Location = new Point(225, 568);
            button51.Margin = new Padding(3, 2, 3, 2);
            button51.Name = "button51";
            button51.Size = new Size(40, 40);
            button51.TabIndex = 53;
            button51.Text = "X";
            button51.UseVisualStyleBackColor = false;
            button51.Click += VirtualKeyboard_Letter_Click;
            // 
            // button52
            // 
            button52.BackColor = Color.FromArgb(224, 224, 224);
            button52.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button52.FlatAppearance.BorderSize = 0;
            button52.FlatStyle = FlatStyle.Flat;
            button52.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button52.ForeColor = Color.FromArgb(51, 51, 51);
            button52.Location = new Point(271, 568);
            button52.Margin = new Padding(3, 2, 3, 2);
            button52.Name = "button52";
            button52.Size = new Size(40, 40);
            button52.TabIndex = 54;
            button52.Text = "C";
            button52.UseVisualStyleBackColor = false;
            button52.Click += VirtualKeyboard_Letter_Click;
            // 
            // button54
            // 
            button54.BackColor = Color.FromArgb(224, 224, 224);
            button54.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button54.FlatAppearance.BorderSize = 0;
            button54.FlatStyle = FlatStyle.Flat;
            button54.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button54.ForeColor = Color.FromArgb(51, 51, 51);
            button54.Location = new Point(317, 568);
            button54.Margin = new Padding(3, 2, 3, 2);
            button54.Name = "button54";
            button54.Size = new Size(40, 40);
            button54.TabIndex = 55;
            button54.Text = "V";
            button54.UseVisualStyleBackColor = false;
            button54.Click += VirtualKeyboard_Letter_Click;
            // 
            // button56
            // 
            button56.BackColor = Color.FromArgb(224, 224, 224);
            button56.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button56.FlatAppearance.BorderSize = 0;
            button56.FlatStyle = FlatStyle.Flat;
            button56.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button56.ForeColor = Color.FromArgb(51, 51, 51);
            button56.Location = new Point(363, 568);
            button56.Margin = new Padding(3, 2, 3, 2);
            button56.Name = "button56";
            button56.Size = new Size(40, 40);
            button56.TabIndex = 56;
            button56.Text = "B";
            button56.UseVisualStyleBackColor = false;
            button56.Click += VirtualKeyboard_Letter_Click;
            // 
            // button58
            // 
            button58.BackColor = Color.FromArgb(224, 224, 224);
            button58.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button58.FlatAppearance.BorderSize = 0;
            button58.FlatStyle = FlatStyle.Flat;
            button58.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button58.ForeColor = Color.FromArgb(51, 51, 51);
            button58.Location = new Point(410, 568);
            button58.Margin = new Padding(3, 2, 3, 2);
            button58.Name = "button58";
            button58.Size = new Size(40, 40);
            button58.TabIndex = 57;
            button58.Text = "N";
            button58.UseVisualStyleBackColor = false;
            button58.Click += VirtualKeyboard_Letter_Click;
            // 
            // button59
            // 
            button59.BackColor = Color.FromArgb(224, 224, 224);
            button59.FlatAppearance.BorderColor = Color.FromArgb(224, 224, 224);
            button59.FlatAppearance.BorderSize = 0;
            button59.FlatStyle = FlatStyle.Flat;
            button59.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold);
            button59.ForeColor = Color.FromArgb(51, 51, 51);
            button59.Location = new Point(455, 568);
            button59.Margin = new Padding(3, 2, 3, 2);
            button59.Name = "button59";
            button59.Size = new Size(40, 40);
            button59.TabIndex = 58;
            button59.Text = "M";
            button59.UseVisualStyleBackColor = false;
            button59.Click += VirtualKeyboard_Letter_Click;
            // 
            // button60
            // 
            button60.BackColor = Color.DeepSkyBlue;
            button60.FlatAppearance.BorderColor = Color.DeepSkyBlue;
            button60.FlatAppearance.BorderSize = 2;
            button60.FlatStyle = FlatStyle.Flat;
            button60.Font = new Font("Microsoft Sans Serif", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button60.ForeColor = Color.FromArgb(66, 66, 66);
            button60.Location = new Point(89, 568);
            button60.Margin = new Padding(3, 2, 3, 2);
            button60.Name = "button60";
            button60.Size = new Size(83, 40);
            button60.TabIndex = 59;
            button60.Text = "enter";
            button60.UseVisualStyleBackColor = false;
            button60.Click += VirtualKeyboard_Enter_Click;
            // 
            // button53
            // 
            button53.BackColor = Color.DeepSkyBlue;
            button53.FlatAppearance.BorderColor = Color.DeepSkyBlue;
            button53.FlatAppearance.BorderSize = 2;
            button53.FlatStyle = FlatStyle.Flat;
            button53.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button53.ForeColor = Color.FromArgb(66, 66, 66);
            button53.Location = new Point(501, 568);
            button53.Margin = new Padding(3, 2, 3, 2);
            button53.Name = "button53";
            button53.Size = new Size(60, 40);
            button53.TabIndex = 60;
            button53.Text = "⌫";
            button53.UseVisualStyleBackColor = false;
            button53.Click += VirtualKeyboard_BackSpace_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(33, 33, 33);
            ClientSize = new Size(666, 701);
            Controls.Add(button21);
            Controls.Add(button47);
            Controls.Add(button1);
            Controls.Add(button31);
            Controls.Add(button2);
            Controls.Add(button4);
            Controls.Add(button32);
            Controls.Add(button3);
            Controls.Add(label1);
            Controls.Add(button5);
            Controls.Add(button53);
            Controls.Add(button10);
            Controls.Add(button33);
            Controls.Add(button9);
            Controls.Add(button45);
            Controls.Add(button8);
            Controls.Add(button60);
            Controls.Add(button7);
            Controls.Add(button46);
            Controls.Add(button6);
            Controls.Add(button34);
            Controls.Add(button15);
            Controls.Add(button44);
            Controls.Add(button14);
            Controls.Add(button59);
            Controls.Add(button13);
            Controls.Add(button43);
            Controls.Add(button12);
            Controls.Add(button35);
            Controls.Add(button11);
            Controls.Add(button48);
            Controls.Add(button20);
            Controls.Add(button58);
            Controls.Add(button19);
            Controls.Add(button42);
            Controls.Add(button18);
            Controls.Add(button36);
            Controls.Add(button17);
            Controls.Add(button49);
            Controls.Add(button16);
            Controls.Add(button56);
            Controls.Add(button25);
            Controls.Add(button41);
            Controls.Add(button24);
            Controls.Add(button37);
            Controls.Add(button23);
            Controls.Add(button50);
            Controls.Add(button22);
            Controls.Add(button54);
            Controls.Add(button30);
            Controls.Add(button40);
            Controls.Add(button29);
            Controls.Add(button38);
            Controls.Add(button28);
            Controls.Add(button51);
            Controls.Add(button27);
            Controls.Add(button52);
            Controls.Add(button26);
            Controls.Add(button39);
            KeyPreview = true;
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Form1";
            KeyDown += Form1_KeyDown;
            ResumeLayout(false);
            PerformLayout();
        }



        #endregion

        private Label label1;
        private Label label2;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button30;
        private Button button31;
        private Button button32;
        private Button button33;
        private Button button34;
        private Button button35;
        private Button button36;
        private Button button37;
        private Button button38;
        private Button button39;
        private Button button40;
        private Button button41;
        private Button button42;
        private Button button43;
        private Button button44;
        private Button button45;
        private Button button46;
        private Button button47;
        private Button button48;
        private Button button49;
        private Button button50;
        private Button button51;
        private Button button52;
        private Button button54;
        private Button button56;
        private Button button58;
        private Button button59;
        private Button button60;
        private Button button53;
        private Label label3;
    }
}
