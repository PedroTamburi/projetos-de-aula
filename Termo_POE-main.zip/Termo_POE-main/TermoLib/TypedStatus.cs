﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TermoLib
{
    public enum TypedStatus
    {
        NOT_TYPED,
        NOT_IN_WORD,
        RIGHT_POSITION,
        WRONG_POSITION
    }
}
